#include "Pokemon.h"

void Pokemon::info()
{
	// TODO: Print out all the information about this Pokemon.
	cout << "> hp: " << hp << "\n";
	cout << "> attack: " << attack << "\n";
	cout << "> defense: "<< defense << "\n"; 
	cout << "> specialAttack: " << specialAttack << "\n";
	cout << "> specialDefense: " << specialDefense << "\n";
	cout << "> speed: " << speed << "\n";
}